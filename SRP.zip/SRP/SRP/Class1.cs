﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SRP
{
    class Class1 : IUser, IEmployee
    {
        public bool Loggin(string empname, int empid)
        {
            throw new NotImplementedException();
        }

        public bool Register(string name, string pass)
        {
            throw new NotImplementedException();
        }
    }
}
