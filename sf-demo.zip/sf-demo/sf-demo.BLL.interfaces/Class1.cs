﻿using System;

namespace sf_demo.BLL.interfaces
{
    public class Class1
    {
    }
}
