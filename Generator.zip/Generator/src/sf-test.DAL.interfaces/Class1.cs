﻿using System;

namespace sf_test.DAL.interfaces
{
    public class Class1
    {
    }
}
