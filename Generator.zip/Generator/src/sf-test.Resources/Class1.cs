﻿using System;

namespace sf_test.Resources
{
    public class Class1
    {
    }
}
