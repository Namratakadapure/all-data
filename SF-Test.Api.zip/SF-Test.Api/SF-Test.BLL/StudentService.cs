﻿using ClosedXML.Excel;
using SF_Test.BLLInterface;
using SF_Test.Model;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace SF_Test.BLL
{
    public class StudentService : IStudentService
    {
        public byte[] AddStudent(Student request)
        {
            var workingDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Data");
            var excelPath = Path.Combine(workingDirectory, "StudentData.xlsx");

            if (!File.Exists(excelPath))
            {
                var file = new FileStream(excelPath, FileMode.CreateNew, FileAccess.ReadWrite);
                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("Students");
                    var currentRow = 1;

                    worksheet.Cell(currentRow, 1).Value = "StudentId";
                    worksheet.Cell(currentRow, 2).Value = "FName";
                    worksheet.Cell(currentRow, 3).Value = "LName";
                    worksheet.Cell(currentRow, 4).Value = "Roll";
                    workbook.SaveAs(file, true);
                }
                file.Close();
            }

            using (var workbook = new XLWorkbook(excelPath))
            {
                var worksheet = workbook.Worksheets.First(w => w.Name == "Students");
                var currentRow = worksheet.Rows().Count() + 1;
                
                worksheet.Cell(currentRow, 1).Value = request.StudentId;
                worksheet.Cell(currentRow, 2).Value = request.FName;
                worksheet.Cell(currentRow, 3).Value = request.LName;
                worksheet.Cell(currentRow, 4).Value = request.Roll;

                workbook.Save();
            }

            return DownloadFile(excelPath);
        }

        public byte[] DownloadFile(string filePath)
        {
            var file = File.ReadAllBytes(filePath);
            return file;
        }
    }
}
