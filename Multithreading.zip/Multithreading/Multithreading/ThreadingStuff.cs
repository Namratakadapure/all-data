﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Multithreading
{
    class ThreadingStuff
    {
        // public void RunIt()
        // {
        //Thread.Sleep(3000);
        //Console.WriteLine("Hello");

        //for (int i = 0; i < 50; i++)
        //{
        //    //System.Threading.Thread newThread1 = new System.Threading.Thread(ThreadedCode);
        //    //newThread1.Start();
        //    bool result = ThreadPool.QueueUserWorkItem(new WaitCallback(ThreadedCode));
        //}

        //System.Threading.Thread newThread2 = new System.Threading.Thread(ThreadedCode);
        //newThread2.Start();

        //private void ThreadedCode(object o)
        //{
        //    Thread.Sleep(3000);
        //    Console.WriteLine("Hello threading ON world!");
        //}

        //System.Threading.Thread thr4ead = new System.Threading.Thread(ThreadedCode);
        //thr4ead.Start(1);

        //Task mytask = new Task(() => Console.WriteLine("From Lamda"));
        //mytask.Start();

        //Task mytask = new Task(ThreadedCode);
        //mytask.Start();


        //Task mytask = new Task(() =>
        //  {
        //      Console.WriteLine("Start wait");
        //      Thread.Sleep(3000);
        //      Console.WriteLine("Done Wait");
        //  });
        //mytask.Start();
        //}

        //public  Task<string> RunIt()
        //{ 
        //        Task <string>myTask= new Task<string>(() => {
        //            Console.WriteLine("Start wait");
        //            Thread.Sleep(3000);
        //            Console.WriteLine("Done Wait");
        //            return "Smith";
        //        });
        //        myTask.Start();
        //        return myTask;    
        //}

        //private void ThreadedCode(object i)
        //{
        //    Thread.Sleep(3000);
        //    Console.WriteLine("Hello threading ON world!");
        //}


        //private void ThreadedCode()
        //{
        //    Thread.Sleep(3000);
        //    Console.WriteLine("Hello threading ON world!");
        //}



        //private int _counter =0;

        //public Task<string> RunIt()
        //{ 
        //       Task <string>myTask= new Task<string>(() => {

        //        Thread.Sleep(2000);
        //           _counter++;
        //        return "Smith" + _counter;
        //  });
        //   myTask.Start();
        //return myTask;    
        //}

        //private int _counter = 0;

        //public void RunIt()
        //{
        //    for (int i = 0; i < 1; i++)
        //    {
        //        Task myTask = new Task(() => {

        //            Thread.Sleep(2000);
        //                    _counter++;
        //             Console.WriteLine("Smith" + _counter);
        //        });
        //            myTask.Start();
        //    }
        //}


        //private int _counter = 0;
        //public static object myLocker = 1;
        //public void RunIt()
        //{
        //    for (int i = 0; i < 50; i++)
        //    {
        //        Task myTask = new Task(() =>
        //        {

        //            Thread.Sleep(2000);
        //            lock (myLocker)
        //            {
        //                _counter++;
        //            }
        //            Console.WriteLine("Smith" + _counter);
        //        });
        //        myTask.Start();
        //    }
        //}


        private int _counter = 0;
        public static object myLocker = 1;
        public void RunIt()
        {
            const int loops = 5000;
            Task[] tasks = new Task[loops];
         for (int i = 0; i < loops; i++)
         {
            Task myTask = new Task(() =>
              {
                  lock (myLocker)
                  {
                      _counter++;
                  }
                //  Console.WriteLine("Smith" + _counter);
              });


              myTask.Start();
              tasks[i] = myTask;
          }
            Task t = Task.WhenAll(tasks);
            try
            {
                t.Wait();
            }
            catch { }
            Console.WriteLine("All tasks done! " + _counter);
        }
    }
}




