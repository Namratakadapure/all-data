﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Controller
{
    public class Employee
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; } = "";
        public string Designation { get; set; }
        public long Salary { get; set; }
        public bool IsIndian { get; set; } = false;
    }
}
