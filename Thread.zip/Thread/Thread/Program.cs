﻿using System;
using System.IO;


namespace Thread
{
    class Program
    {
        static void Main(string[] args)
        {
            //[Creating  file using thread]

            //FileStream f = new FileStream("d:\\a.txt", FileMode.OpenOrCreate);
            //f.WriteByte(65);
            //f.Close();


            //[Creating file and write some data in file using thread]

            FileStream f = new FileStream("d:\\output.txt", FileMode.Create);
            StreamWriter s = new StreamWriter(f);
            s.WriteLine("hello Everyone");
            s.Close();
            f.Close();
            Console.WriteLine("File Created Succesfully...");



            //[Creating file and read some data in file using thread]

            //FileStream f = new FileStream("d:\\o.txt", FileMode.OpenOrCreate);
            //StreamReader s = new StreamReader(f);

            //string line = s.ReadLine();
            //Console.WriteLine(line);

            //s.Close();
            //f.Close();

            //OpenFileDialog ofd = new OpenFileDialog();
            //ofd.DefaultExt = ".txt";
            //ofd.Filter = "Text Document (.txt)|*.txt";
            //FileStream f = new FileStream("d:\\demo.txt", FileMode.Create);
            //StreamWriter s = new StreamWriter(f);
            //s.WriteLine(".NET Core is the latest general purpose development platform maintained by Microsoft. It works across different platforms and has been redesigned in a way that makes .NET fast, flexible and modern. This happens to be one of the major contributions by Microsoft. Developers can now build Android, iOS, Linux, Mac, and Windows applications with .NET, all in Open Source.In this tutorial, we will cover.NET Core and a few new innovations including the.NET Framework updates, .NET Standard, and Universal Windows Platform updates, etc.");
            //s.Close();
            //f.Close();
            //Console.WriteLine("File Created Succesfully...");

        }
    }
}
