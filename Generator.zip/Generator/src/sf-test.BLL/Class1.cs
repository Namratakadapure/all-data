﻿using System;

namespace sf_test.BLL
{
    public class Class1
    {
    }
}
