﻿using System;

namespace sf_demo.DAL.interfaces
{
    public class Class1
    {
    }
}
