﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SF_Test.Model;
using System.IO;
using Microsoft.AspNetCore.StaticFiles;
using SF_Test.BLLInterface;

namespace SF_Test.Api.Controllers
{

    public class ExcelController : ControllerBase
    {
        private readonly IExcelService excelService;

        public ExcelController(IExcelService excelService)
        {
            this.excelService = excelService;
        } 
        [HttpGet("GenerateExcel")]
        public async Task<ActionResult> GenerateExcel()
        {
            string FilePathName = Path.Combine(Directory.GetCurrentDirectory(), "Upload\\file", "TestReport" + DateTime.Now.Ticks.ToString() + ".xls");
            List<ExcelSheetModel> lstStudData = excelService.GetExcelData();
            string htmlstring = "<table style='width:800px;border:solid;border-width:1px'><thead><tr>";
            htmlstring += "<th style='width:100px;text-align:left;'>Slno </th>";
            htmlstring += "<th style='width:100px;text-align:left;'>StudName </th>";
            htmlstring += "<th style='width:100px;text-align:left;'>Dept </th>";
            htmlstring += "<th style='width:100px;text-align:left;'>Address </th>";
            htmlstring += "</tr></thead><tbody>";

            foreach (ExcelSheetModel obj in lstStudData)
            {
                htmlstring += "<tr><td style='width:100%;text-align:left;'>" + obj.Slno.ToString() + "</td>";
                htmlstring += "<td style='width:100%;text-align:left;'>" + obj.StudName.ToString() + "</td>";
                htmlstring += "<td style='width:100%;text-align:left;'>" + obj.Dept.ToString() + "</td>";
                htmlstring += "<td style='width:100%;text-align:left;'>" + obj.Address.ToString() + "</td></tr>";
            }
            htmlstring += "</tbody></table>";
            System.IO.File.AppendAllText(FilePathName, htmlstring);

            var provider = new FileExtensionContentTypeProvider();
            if (!provider.TryGetContentType(FilePathName, out var contentType))
            {
                contentType = "application/octet-stream";
            }
            var bytes = await System.IO.File.ReadAllBytesAsync(FilePathName);
            return File(bytes, contentType, Path.GetFileName(FilePathName));
        }
    }
}