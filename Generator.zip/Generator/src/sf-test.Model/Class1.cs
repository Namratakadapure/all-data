﻿using System;

namespace sf_test.Model
{
    public class Class1
    {
    }
}
