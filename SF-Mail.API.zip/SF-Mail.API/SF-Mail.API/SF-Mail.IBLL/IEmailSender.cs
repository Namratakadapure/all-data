﻿using SF_Mail.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF_Mail.IBLL
{
  public  interface IEmailSender 
    {
        void SendEmail(Message message);
        Task SendEmailAsync(Message message);
    }
}
