﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace demomutex
{
    class Program
    {
        static void Main(string[] args)
        {
            Mutex mutex = new Mutex();
            Thread[] threads = new Thread[10];

            //creating threads
            for(int i=0;i<threads.Length;i++)
            {
                threads[i] = new Thread(EnterClub);
            }
            //statring threads
            for (int i = 0; i < threads.Length; i++)
            {
                threads[i].Start(mutex);
            }
            //joining
            for (int i = 0; i < threads.Length; i++)
            {
                threads[i].Join();
            }
            Console.WriteLine("All Done");
            Console.ReadLine();
            
        }
        private static void EnterClub(object arg)
        {
            Console.WriteLine($"{Thread.CurrentThread.ManagedThreadId}Arrived &Waiting...");
            Mutex mutex = arg as Mutex;
            mutex.WaitOne();
            Console.WriteLine($"{Thread.CurrentThread.ManagedThreadId}Entered");
            Thread.Sleep(4000);
            Console.WriteLine($"{Thread.CurrentThread.ManagedThreadId}Exit.");
            mutex.ReleaseMutex();
        }
    }
}



