﻿using System;
using System.Threading;

namespace ThreadClass
{
    class Program
    {
        class ThreadClass
        {
            static void Main(string[] args)
            {
                try
                {
                    Thread th = new Thread(new ThreadStart(stuff));
                    th.Start();
                    th.Join();
                  
                }
                catch (Exception e)
                {
                    Console.Write(e);
                }
                Console.Read();
            }
            static void stuff()
            {
                Console.Write("Thread 1 running");
                Thread.Sleep(3000);
            }
        }
    }
}

