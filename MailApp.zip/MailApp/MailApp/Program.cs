﻿using System;
using MailKit.Net.Smtp;
using MailKit;
using MimeKit;

namespace MailApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //create a new mime message object which we are goging to use to fill the message data.
            MimeMessage message = new MimeMessage();
            //add the sender info that will apper in the email message
            message.From.Add(new MailboxAddress("pranav walunj", "shital.jadhav@simplifai.ai"));

            // add the reciver email address
            message.To.Add(MailboxAddress.Parse("pranavwalunj1998@gmail.com"));

            // add the message subject
            message.Subject = "Task!.";

            //add the message body as plain text the plain"plain" to pass the string 
            //indicates that it's plain text and not html for example
            message.Body = new TextPart("plain")
            {
                Text = @"Yes,
                Hello!.
             This is dog!"
            };
            //ask the user to enter the email
            Console.Write("Email:");
            string emailAddress = Console.ReadLine();
            // ask the user to enter the password
            Console.Write("Password:");

            //for secqurity resons we need to mask the password,
            //store original values of the consolesbackground and forground colour

            ConsoleColor originalBGColor = Console.BackgroundColor;
            ConsoleColor orginalFGColor = Console.ForegroundColor;

            //set the console background and foreground colors to red for examples
            Console.BackgroundColor = ConsoleColor.Green;
            Console.BackgroundColor = ConsoleColor.Green;

            // read the password
            string password = Console.ReadLine();

            //set the consoles background and foreground colors back
            Console.BackgroundColor = originalBGColor;
            Console.ForegroundColor = orginalFGColor;

            //create a new SMTP client
            SmtpClient client = new SmtpClient();

            try
            {
                //connect to the gmail smtp server using port 465 with
                client.Connect("smtp.gmail.com", 465, true);
                //Note: only needed if the Smtp server requries auth
                client.Authenticate(emailAddress, password);
                client.Send(message);

                //display a messge if no exception was thrown
                Console.WriteLine("Email Sent!.");
            
            }
             
            catch (Exception ex)
            {
                //in case of an error display the message
                Console.WriteLine(ex.Message);
            }
            finally
            {
                //at any case always disconnect from the client
                client.Disconnect(true);
                //and dispose of the client object
                client.Dispose();
            }
            Console.ReadLine();
        }
    }
}
