﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task.Model;

namespace Task.DAL
{

public partial class TaskDbContext : DbContext
    {
        public TaskDbContext(DbContextOptions<TaskDbContext> options) : base(options) { }

        public virtual DbSet<Address> Addresses { get; set; }
        public virtual DbSet<ToDo> Todos { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Address>(entity => {
                entity.ToTable("Address");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.City).HasMaxLength(32).IsFixedLength(true);

                entity.Property(e => e.Street).HasMaxLength(1024);

                entity.Property(e => e.Suite).HasMaxLength(512);

                entity.Property(e => e.Zip).IsRequired().HasMaxLength(16).IsFixedLength(true);

                //entity.HasOne(d => d.User).WithMany(p => p.Addresses).HasForeignKey(d => d.UserId).HasConstraintName("FK_Address");
            });

            modelBuilder.Entity<ToDo>(entity => {
                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Title).HasMaxLength(128);

                entity.HasOne(d => d.User).WithMany(p => p.Todos).HasForeignKey(d => d.UserId).HasConstraintName("FK_Todos_User");
            });

            modelBuilder.Entity<User>(entity => {
                entity.ToTable("User");

                entity.Property(e => e.Id).ValueGeneratedNever();

                entity.Property(e => e.Email).IsRequired().HasMaxLength(128);

                entity.Property(e => e.Name).HasMaxLength(128);

                entity.Property(e => e.Phone).HasMaxLength(128);

                entity.Property(e => e.Username).HasMaxLength(128);

                entity.Property(e => e.Website).HasMaxLength(128);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}


