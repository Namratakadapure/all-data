﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace Task.Model
{
    public partial class User
    {
        public User()
        {
            Addresses = new HashSet<Address>();
            Todos = new HashSet<ToDo>();
        }

        public int Id { get; set; }
        public string Username { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Website { get; set; }
        public Address Address { get; set; }

       public virtual ICollection<Address> Addresses { get; set; }
        public virtual ICollection<ToDo> Todos { get; set; }
    }
}
