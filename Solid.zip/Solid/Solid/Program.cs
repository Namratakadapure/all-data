﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solid
{
    class Program
    {
        static void Main(string[] args)
        {
            CalculateSalary s = new CalculateSalary { numberOfDays = 20, perDayRate = 1000 };
            var salary = s.CalculateSal();
            PrintSalary p = new PrintSalary();
            p.PrintSalaray(salary);
            Console.ReadKey(true);
        }
    }
}
