﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.StaticFiles;
using System.Threading.Tasks;
using System.IO;
using SF_MailDemo.Model;
using Microsoft.AspNetCore.Http;
using SF_MailDemo.BLL;

namespace SF_MailDemo.Controllers
{
   
    public class ExcelController : ControllerBase
    {
        public List<ExcelSheetModel> GetExcelData()
        {
            List<ExcelSheetModel> ListData = new List<ExcelSheetModel>
            {
                new ExcelSheetModel{slno=1, Empname = "Namrata", Dept = "It", Desg = "Trainee DotNet Developer"},
                new ExcelSheetModel{slno=2,Empname="Priya", Dept = "It", Desg = "Trainee DotNet Developer"},

            };
            return ListData;

        }
        [HttpGet("GenerateExcel")]
        public async Task<ActionResult> GenerateExcel()
        {
            string FilePathName = Path.Combine(Directory.GetCurrentDirectory(), "Upload", "TestReport" + DateTime.Now.Ticks.ToString() + ".xls");
            List<ExcelSheetModel> lstStudData = GetExcelData();
            string htmlstring = "<table style='width:800px;border:solid;border-width:1px'><thead><tr>";
            htmlstring += "<th style='width:110px;text-align:left;'>slno </th>";
            htmlstring += "<th style='width:130px;text-align:left;'>Empname </th>";
            htmlstring += "<th style='width:130px;text-align:left;'>Dept </th>";
            htmlstring += "<th style='width:130px;text-align:left;'>Desg </th>";
            htmlstring += "</tr></thead><tbody>";

            foreach (ExcelSheetModel obj in lstStudData)
            {
                htmlstring += "<tr><td style='width:10%;text-align:left;'>" + obj.slno.ToString() + "</td>";
                htmlstring += "<td style='width:30%;text-align:left;'>" + obj.Empname.ToString() + "</td>";
                htmlstring += "<td style='width:30%;text-align:left;'>" + obj.Dept.ToString() + "</td>";
                htmlstring += "<td style='width:30%;text-align:left;'>" + obj.Desg.ToString() + "</td></tr>";
            }
            htmlstring += "</tbody></table>";
            System.IO.File.AppendAllText(FilePathName, htmlstring);

            var provider = new FileExtensionContentTypeProvider();
            if (!provider.TryGetContentType(FilePathName, out var contentType))
            {
                contentType = "application/octet-stream";
            }
            var bytes = await System.IO.File.ReadAllBytesAsync(FilePathName);
            return File(bytes, contentType, Path.GetFileName(FilePathName));
        }

    }
}

