﻿using AutoMapper;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Test.BLL.mapper;
using Test.DAL;
using Test.Models;

namespace Test.BLL
{
    public class TestService
    {
        private readonly TestRepository _testRepository;
        private readonly IMapper mapper;

        public TestService(TestRepository taskRepository, IMapper mapper)
        {
            _testRepository = taskRepository;
            this.mapper = mapper;
        }

        async Task<string> ExecuteGetRequest(string url)
        {
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Accept", "application/json");

            var apiresponse = await client.GetAsync(new Uri(url));
            if (apiresponse.IsSuccessStatusCode)
            {
                string result = await apiresponse.Content.ReadAsStringAsync();
                return result;
            }
            throw new Exception("Api Call Failed");
        }

        public async Task<bool> InsertUserData()
        {
            var url = "https://jsonplaceholder.typicode.com/users";
            var res = await ExecuteGetRequest(url);
            var users = JsonConvert.DeserializeObject<List<User>>(res);
            users.ForEach(u => u.Address.UserId = u.Id);
            var isSuccess = await _testRepository.InsertUsersIntoDb(users);
            if (isSuccess is true)
            {
                var addresses = users.Select(a => a.Address).ToList();
                isSuccess = await _testRepository.InsertAddressIntoDb(addresses);
                return isSuccess;
            }
            else
            {
                return false;
            }
        }
        public async Task<bool> InsertTodoData()
        {
            var url = "https://jsonplaceholder.typicode.com/todos";
            var res = await ExecuteGetRequest(url);
            var todos = JsonConvert.DeserializeObject<List<Todo>>(res);
            var isSuccess = await _testRepository.InsertTodoIntoDb(todos);
            if (isSuccess is true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public async Task<List<createUser>> GetUsers()
        {
            var result = await _testRepository.GetUsers();
            var users = mapper.Map<List<createUser>>(result);
            return users;
        }
      
    }
}