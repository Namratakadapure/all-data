﻿using SF_Test.Model;

namespace SF_Test.BLLInterface
{
    public interface IStudentService
    {
        byte[] AddStudent(Student request);
        byte[] DownloadFile(string filePath);
    }
}