﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ExcelExport.Model;
using System.IO;
using Microsoft.AspNetCore.StaticFiles;

namespace ExcelExport.Controllers
{
 
    public class ExcelController : ControllerBase
    {
        public List<ExcelSheetModel> GetExcelData()
        {
            List<ExcelSheetModel> ListData = new List<ExcelSheetModel>
            {
                new ExcelSheetModel{Slno=1,StudName="Radha",Dept="CSE",Address="Sangli"},
                new ExcelSheetModel{Slno=1,StudName="Priya",Dept="Mech",Address="Mumbai"},
                new ExcelSheetModel{Slno=1,StudName="Meera",Dept="Civil",Address="Pune"},
                new ExcelSheetModel{Slno=1,StudName="Tasnim",Dept="CSE",Address="Sangli"},
                new ExcelSheetModel{Slno=1,StudName="Disha",Dept="E&Tc",Address="Miraj"},
                new ExcelSheetModel{Slno=1,StudName="Saniya",Dept="CSE",Address="Satara"},
            };
            return ListData;

        }
        [HttpGet("GenerateExcel")]
        public async Task<ActionResult>GenerateExcel()
        {
            string FilePathName = Path.Combine(Directory.GetCurrentDirectory(), "Upload\\files", "TestReport"+DateTime.Now.Ticks.ToString()+".xls");
            List<ExcelSheetModel> lstStudData = GetExcelData();
            string htmlstring = "<table style='width:800px;border:solid;border-width:1px'><thead><tr>";
            htmlstring += "<th style='width:100px;text-align:left;'>Slno </th>";
            htmlstring += "<th style='width:100px;text-align:left;'>StudName </th>";
            htmlstring += "<th style='width:100px;text-align:left;'>Dept </th>";
            htmlstring += "<th style='width:100px;text-align:left;'>Address </th>";
            htmlstring += "</tr></thead><tbody>";

            foreach(ExcelSheetModel obj in  lstStudData)
            {
                htmlstring += "<tr><td style='width:10%;text-align:left;'>"+obj.Slno.ToString()+"</td>";
                htmlstring += "<td style='width:30%;text-align:left;'>" + obj.StudName.ToString() + "</td>";
                htmlstring += "<td style='width:30%text-align:left;'>" + obj.Dept.ToString() + "</td>";
                htmlstring += "<td style='width:30%;text-align:left;'>" + obj.Address.ToString() + "</td></tr>";
            }
            htmlstring += "</tbody></table>";
            System.IO.File.AppendAllText(FilePathName, htmlstring);

            var provider = new FileExtensionContentTypeProvider();
            if(!provider.TryGetContentType(FilePathName,out var contentType))
            {
                contentType = "application/octet-stream";
            }
            var bytes = await System.IO.File.ReadAllBytesAsync(FilePathName);
            return File(bytes, contentType, Path.GetFileName(FilePathName));
        }

    }
}

