﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Controller
{
    public class EmployeeService
    {

        // accessModifier dataType propertyName/memberName{}
        public string UserRole { get; set; } = "ReadOnly";

        // accessModifier returnType methodType(){}
        public Employee GetEmployee()
        {
            var emp = new Employee
            {
                Id = 1,
                Name = "Namrata",
                Designation = "Trainee",
                Salary = 30000
            };
            return emp;
        }

        public List<Employee> GetEmployees()
        {
            //var abc = new int[6];
            var listOftEmployee = new List<Employee>()
            {
                new Employee
                {
                    Id = 1,
                    Name = "Namrata",
                    Designation = "Trainee",
                    Salary = 30000
                },
                new Employee
                {
                    Id = 2,
                    Name = "Shital",
                    Designation = "Trainee",
                    Salary = 30000
                }
            };

            //ToList() - used to convert collection of object to list of object
            return listOftEmployee;
        }
    }
}
