﻿using System;

namespace sf_demo.DAL
{
    public class Class1
    {
    }
}
