﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Task.IBLL.Interface;
using Task.Model;

namespace Task.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class APIController : ControllerBase
    {
        private readonly ITaskService _taskService;
        public APIController(ITaskService taskService)
        {
            _taskService = taskService;
        }
        [HttpGet("InsertUsers")]
        public async Task<ActionResult> InsertUsers()
        {
            var result = await _taskService.InsertUserData();
            return Ok(result);
        }

        [HttpGet("InsertToDos")]
        public async Task<ActionResult> InsertToDos()
        {
            var result = await _taskService.InsertToDoData();
            return Ok(result);
        }

        [HttpGet("GetUsers")]
        public async Task<ActionResult> GetUsers()
        {
            var result = await _taskService.GetUsers();
            return Ok(result);
        }

    }
}
