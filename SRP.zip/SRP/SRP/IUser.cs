﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SRP
{
    interface IUser
    {
      
        bool Register(string name,string pass);
        
        
    }
    interface IEmployee
    {
        bool Loggin(string empname, int empid);
    }
}
