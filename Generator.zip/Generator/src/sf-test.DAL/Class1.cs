﻿using System;

namespace sf_test.DAL
{
    public class Class1
    {
    }
}
