﻿using System;

namespace sf_test.BLL.interfaces
{
    public class Class1
    {
    }
}
