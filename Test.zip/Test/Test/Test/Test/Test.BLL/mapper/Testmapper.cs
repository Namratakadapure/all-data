﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.Models;

namespace Test.BLL.mapper
{
   public  class Testmapper:Profile
    {
        public Testmapper()
        {
            CreateMap<User, createUser>();
            CreateMap<Todo, createToDo>();
            CreateMap<Address, createAddress>();

        }
    }
}
