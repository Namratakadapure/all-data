﻿using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Options;
using MimeKit;
using SF_MailDemo.IBLL;
using SF_MailDemo.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF_MailDemo.BLL
{
   public class EmailSender : IEmailSender
    {
        private readonly Message _message;
        public EmailSender(IOptions<Message> message)
        {
            _message = message.Value;
        }
        public async Task SendEmailAsync(EmailConfiguration emailConfiguration)
        {
            var email = new MimeMessage();
            email.Sender = MailboxAddress.Parse(_message.Mail);
            email.To.Add(MailboxAddress.Parse(emailConfiguration.ToEmail));
            email.Subject = emailConfiguration.Subject;
            var builder = new BodyBuilder();
            if (emailConfiguration.Attachments != null)
            {
                byte[] fileBytes;
                foreach (var file in emailConfiguration.Attachments)
                {
                    if (file.Length > 0)
                    {
                        using (var ms = new MemoryStream())
                        {
                            file.CopyTo(ms);
                            fileBytes = ms.ToArray();
                        }
                        builder.Attachments.Add(file.FileName, fileBytes, ContentType.Parse(file.ContentType));
                    }
                }
            }
            builder.HtmlBody = emailConfiguration.Body;
            email.Body = builder.ToMessageBody();
            using var smtp = new SmtpClient();
            smtp.Connect(_message.Host, _message.Port, SecureSocketOptions.StartTls);
            smtp.Authenticate(_message.Mail, _message.Password);
            await smtp.SendAsync(email);
            smtp.Disconnect(true);
        }
    }
    



    
}
