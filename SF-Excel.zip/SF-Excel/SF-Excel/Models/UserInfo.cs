﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF_Excel.Models
{
    public class UserInfo
    {
        public string UserName { get; set; }
        public int Age { get; set; }
    }
}
