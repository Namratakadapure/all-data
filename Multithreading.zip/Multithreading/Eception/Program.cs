﻿using System;
using System.IO;

namespace Eception
{
    class Program
    {

        static void Main(string[] args)
        {
            //Console.WriteLine("enter first number:");
            //int num1 = int.Parse(Console.ReadLine());
            //Console.WriteLine("enter second number: ");
            //int num2 = int.Parse(Console.ReadLine());
            //try
            //{
            //    int result = num1 / num2;
            //    Console.WriteLine("Division result is:" + result);
            //}
            //catch (DivideByZeroException ex)
            //{
            //    Console.WriteLine("You can not divide a number by zero");
            //    Console.WriteLine(ex.Message);
            //}


            //try
            //{
            //    int a, b, c;
            //    Console.WriteLine("Enter value of a");
            //    a = int.Parse(Console.ReadLine());
            //    Console.WriteLine("Enter value of b");
            //    b = int.Parse(Console.ReadLine());
            //    c = a / b;
            //    Console.WriteLine("Division of a by b is= " + c);
            //}
            //catch (DivideByZeroException ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //catch (FormatException ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}
            //finally
            //{
            //    Console.WriteLine("Program Executed");
            //}


            //****** Out Off Array Exceptions ************** //


            {
                try
                {
                    int[] arr = new int[5];
                    arr[2] = 25;
                    Console.WriteLine(arr[2]);
                }
                catch (IOException e)
                {
                    Console.WriteLine("arrya is out of limit please provide the value in limi");
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine("out of arry range");
                }
                catch (DivideByZeroException)
                {
                    Console.WriteLine("Divde by zero");
                }
                finally
                {
                    Console.WriteLine("program terminated");
                }

            }
        }
    }
}


