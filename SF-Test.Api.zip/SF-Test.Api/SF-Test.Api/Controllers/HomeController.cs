﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SF_Test.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ClosedXML.Excel;
using System.IO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using SF_Test.BLLInterface;

namespace SF_Test.Api.Controllers
{
    public class HomeController : ControllerBase
    {
        private readonly IStudentService studentService;
        public HomeController(IStudentService studentService)
        {
            this.studentService = studentService;
        }

        [HttpPost("ExportData")]
        public IActionResult Index([FromForm]Student request)
        {
            var result = studentService.AddStudent(request);
            return File(result,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "StudentsDataExcel.xlsx"
                        );
        }
    }
}