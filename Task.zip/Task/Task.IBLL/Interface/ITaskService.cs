﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task.Model;

namespace Task.IBLL.Interface
{
    public interface ITaskService
    {
        Task<List<ToDo>> InsertToDoData();
        Task<List<User>> InsertUserData();
        Task<List<User>> GetUsers();

        //ValueTask CreateAddress(int id);
        //ValueTask CreateToDo(int id);
        //ValueTask CreateUser(int id);
    }
}
