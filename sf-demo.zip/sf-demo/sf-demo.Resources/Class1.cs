﻿using System;

namespace sf_demo.Resources
{
    public class Class1
    {
    }
}
