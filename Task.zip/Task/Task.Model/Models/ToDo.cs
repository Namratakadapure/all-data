﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Task.Model
{
    public partial class ToDo
    {
        public int UserId { get; set; }
        public int Id { get; set; }
        public string Title { get; set; }
        public bool? Completed { get; set; }

        public virtual User User { get; set; }
    }
}
