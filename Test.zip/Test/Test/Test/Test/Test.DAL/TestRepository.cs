﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.Models;

namespace Test.DAL
{
    public class TestRepository
    {
        private readonly TestContext _context;

        public TestRepository(TestContext context)
        {
            this._context = context;
        }

        public async Task<List<User>> GetUsers()
        {
            var users = await _context.Users.AsNoTracking().ToListAsync();
            foreach (var user in users)
            {
                user.Address = await _context.Addresses.AsNoTracking().FirstOrDefaultAsync(u => u.UserId == user.Id);
                user.Todos = await _context.Todos.AsNoTracking().Where(t => t.UserId == user.Id).ToListAsync();
            }
            return users;
        }
        public async Task<bool> InsertUsersIntoDb(List<User> listOfUsers)
        {
            try
            {
                var old = await _context.Addresses.ToListAsync();
                if (old != null && old.Count > 0)
                {
                    _context.Addresses.RemoveRange(old);
                    await _context.SaveChangesAsync();
                }

                var oldTodos = await _context.Todos.ToListAsync();
                if (oldTodos != null && oldTodos.Count > 0)
                {
                    _context.Todos.RemoveRange(oldTodos);
                    await _context.SaveChangesAsync();
                }

                var oldUser = await _context.Users.ToListAsync();
                if (oldUser != null && oldUser.Count > 0 )
                {
                    _context.Users.RemoveRange(oldUser);
                    await _context.SaveChangesAsync();
                }

                foreach (var item in listOfUsers)
                {
                    await _context.Users.AddAsync(item);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception e)
            {

                throw e;
            }
            return true;

        }

        public async Task<bool> InsertAddressIntoDb(List<Address> listOfAddress)
        {
            try
            {
                
                foreach (var item in listOfAddress)
                {

                    await _context.Addresses.AddAsync(item);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception e)
            {

                throw e;
            }
            return true;

        }

        public async Task<List<Todo>> GetToDos()
        {
            return await _context.Todos.AsNoTracking().ToListAsync();
        }

        public async Task<bool> InsertTodoIntoDb(List<Todo> todos)
        {
            try
            {
                var old = await _context.Todos.ToListAsync();
                if (old != null && old.Count > 0)
                {
                    _context.Todos.RemoveRange(old);
                    await _context.SaveChangesAsync();
                }

                foreach (var item in todos)
                {
                    await _context.Todos.AddAsync(item);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception e)
            {

                throw e;
            }
            return true;

        }
    }
}
