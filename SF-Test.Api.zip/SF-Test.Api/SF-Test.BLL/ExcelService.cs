﻿using SF_Test.BLLInterface;
using SF_Test.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF_Test.BLL
{
    public class ExcelService : IExcelService
    {
        public List<ExcelSheetModel> GetExcelData()
        {
            List<ExcelSheetModel> ListData = new List<ExcelSheetModel>
            {
                new ExcelSheetModel{Slno=1,StudName="Radha",Dept="CSE",Address="Sangli"},
                new ExcelSheetModel{Slno=1,StudName="Priya",Dept="Mech",Address="Mumbai"},
                new ExcelSheetModel{Slno=1,StudName="Meera",Dept="Civil",Address="Pune"},
                new ExcelSheetModel{Slno=1,StudName="Tasnim",Dept="CSE",Address="Sangli"},
                new ExcelSheetModel{Slno=1,StudName="Disha",Dept="E&Tc",Address="Miraj"},
                new ExcelSheetModel{Slno=1,StudName="Saniya",Dept="CSE",Address="Satara"},
            };
            return ListData;

        }
    }
}
