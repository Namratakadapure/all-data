﻿using System;

namespace sf_demo.BLL
{
    public class Class1
    {
    }
}
