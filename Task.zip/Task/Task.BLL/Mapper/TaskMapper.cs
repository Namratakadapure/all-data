﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task.Model;

namespace Task.BLL.Mapper
{
    public class TaskMapper: Profile
    {
        public TaskMapper()
        {
            CreateMap<ToDo, CreateToDo>();
            CreateMap<User, CreateUser>();
            CreateMap<Address, CreateAddress>();
            
        }
    }
}
