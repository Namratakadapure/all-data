﻿using System;

namespace crud.models
{
    public class Class1
    {
    }
}
