﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF_MailDemo.BLL
{
   public class ExcelSheetModel
    {

        public int slno { get; set; }
        public string Empname { get; set; }
        public string Dept { get; set; }
        public string Desg { get; set; }

    }
}
