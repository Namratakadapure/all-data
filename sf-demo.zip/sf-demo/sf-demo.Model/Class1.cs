﻿using System;

namespace sf_demo.Model
{
    public class Class1
    {
    }
}
