﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SF_Mail.IBLL;
using SF_Mail.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SF_Mail.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };
        private readonly IBLL.IEmailSender _emailSender;

        //private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(IBLL.IEmailSender emailSender)
        {
            _emailSender = emailSender;
        }

        [HttpGet]
        public async Task< IEnumerable<WeatherForecast>> Get()
        {
            var rng = new Random();

            var message = new Message(new string[] { "noreply@simplifai.ai" }, "Test email async", "This is the content from our email",null);
           await  _emailSender.SendEmailAsync(message);


            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }
        [HttpPost]

        public async Task<IEnumerable<WeatherForecast>> Post()

        {
            var rng = new Random();
            var files = Request.Form.Files.Any() ? Request.Form.Files : new FormFileCollection();
            var message = new Message(new string[] { "noreply@simplifai.ai" }, "Test email with attachments", "This is the content from our email with attachments.",null);
            await _emailSender.SendEmailAsync(message);


            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();


        }
    }
}
