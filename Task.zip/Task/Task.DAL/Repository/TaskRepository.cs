﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task.Model;

namespace Task.DAL.Repository
{
    public class TaskRepository
    {
        private readonly TaskDbContext _context;
        public TaskRepository(TaskDbContext context)
        {
            _context = context;
        }

        public async Task<List<ToDo>> GetToDos()
        {
            return await _context.Todos.ToListAsync();
        }

        public async Task<ToDo> GetToDo(int UserId)
        {
            var ToDoTask = await _context.Todos.FindAsync( UserId);
            return ToDoTask;
        }

        public async Task<List<User>> GetUsers()
        {
            var users = await _context.Users.AsNoTracking().ToListAsync();
            //foreach (var user in users)
            //{
            //    user.Todos = await _context.Todos.AsNoTracking().Where(u => u.UserId == user.Id).ToListAsync();
            //}
            //foreach (var user in users)
            //{
            //    user.Addresses = await _context.Addresses.AsNoTracking().Where(u => u.UserId == user.Id).ToListAsync();
            //}
            return users;
        }

        public async Task<bool> InsertTodosIntoDb(List<ToDo> listOfTodos)
        {
            var lists = await _context.Todos.AsNoTracking().ToListAsync();
            if (lists != null)
            {
                _context.Todos.RemoveRange();
                await _context.SaveChangesAsync();
            }
       
            try
            {
                foreach (var todo in listOfTodos)
                {
                    var obj = await _context.Todos.AddAsync(todo);

                }
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception e)
            {

                throw e;
            }

        }

        public async Task<bool> InsertUsersIntoDb(List<User> listOfUsers)
        {
            var list = await _context.Addresses.AsNoTracking().ToListAsync();
            if (list != null)
            {
                _context.Addresses.RemoveRange();
            }

            var lists = await _context.Users.AsNoTracking().ToListAsync();
            if (lists != null)
            {
                _context.Users.RemoveRange();
            }

            foreach (var user in listOfUsers)
            {
                try
                {
                    await _context.Users.AddAsync(user);

                }
                catch (Exception e)
                {

                    throw e;
                }
            }

            foreach (var user in listOfUsers)
            {
                try
                {
                    await _context.Addresses.AddAsync(user.Address);

                }
                catch (Exception e)
                {

                    throw e ;
                }
            }
            await _context.SaveChangesAsync();
            return true;

        }

    }
}
