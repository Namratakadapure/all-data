﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solid
{
    class SRP
    {
    }
    public class CalculateSalary
    {
        public double perDayRate { get; set; }
        public double numberOfDays { get; set; }

        public double CalculateSal()         
        {
            return this.perDayRate * this.numberOfDays;
        }
    }
    public class PrintSalary
    {
        public void PrintSalaray(double salary)            
        {
            Console.WriteLine(salary);
        }
    }
}

