﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Test.BLL;

namespace Test.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private readonly TestService testService;

        public TestController(TestService testService)
        {
            this.testService = testService;
        }

        [HttpPost("InsertUsers")]
        public async Task<ActionResult> InsertUsers()
        {
            var result = await testService.InsertUserData();
            return Ok(result);
        }

        [HttpPost("InsertTodo")]
        public async Task<ActionResult> InsertTodo()
        {
            var result = await testService.InsertTodoData();
            return Ok(result);
        }

        [HttpGet("GetUsers")]
        public async Task<ActionResult> GetUsers()
        {
            var users = await testService.GetUsers();
            return Ok(users);
        }

    }
}
