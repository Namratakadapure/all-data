﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.IO;

namespace Multithreading
{
    class Program
    {
        static void Main(string[] args)
        {

            // Console.WriteLine("Starting....");
            //ThreadingStuff stuff = new ThreadingStuff();
            // stuff.RunIt();

            //new ThreadingStuff().RunIt();
            //Thread.Sleep(10000);
            //Console.WriteLine("Done....");


            // Console.WriteLine("Starting....");
            //System.Threading.Tasks.Task<string> surnameTask = new ThreadingStuff().RunIt();
            //Console.WriteLine("Surname:" + surnameTask.Result);
            //Thread.Sleep(5000);
            //Console.WriteLine("Done....");

            // Console.WriteLine("Starting....");
            //new ThreadingStuff().RunIt();
            //Thread.Sleep(5000);
            //Console.WriteLine("Done....");

            //Console.WriteLine("Starting....");
            //new ThreadingStuff().RunIt();
            //Thread.Sleep(2000);
            //Console.WriteLine("Done....");


            //Console.WriteLine("Starting....");
            //new ThreadingStuff().RunIt();
            //Thread.Sleep(2000);
            //Console.WriteLine("Done....");


            //Console.WriteLine("starting..");
            //new AsAwait().DoIt();
            //System.Threading.Thread.Sleep(5000);
            //Console.WriteLine("Done..");


            //Mutex is used

            //int counter = 0;

            ////create the mutex
            //Mutex _m = new Mutex();

            ////crete the Threds T1 and T2
            //Thread T1 = new Thread(() =>
            //  {

            //          _m.WaitOne(); //take the mutex

            //          _m.ReleaseMutex();  //release it for the another Threads

            //  });
            //Thread T2 = new Thread(() =>
            //{

            //        _m.WaitOne(); //take the mutex

            //        _m.ReleaseMutex();  //release it for the another Threads

            //});

            ////Start the Threads
            //T1.Start();
            //T2.Start();

            ////Wait untill they finish
            //T1.Join();
            //T2.Join();

            ////print out the result of counter
            //Console.WriteLine(counter);
            //Console.Read();


            //Mutex is used

            //Mutex mutex = new Mutex();
            //for (int i = 0; i < 10; i++)
            //{
            //    Task.Factory.StartNew(() =>
            //    {
            //        if (mutex.WaitOne(4000))
            //        {
            //            try
            //            {
            //                Console.WriteLine(File.ReadAllText(@"D:\hello.txt"));
            //                File.AppendAllText(@"D:\hello.txt", "Hello");
            //                Thread.Sleep(5000);
            //            }
            //            finally
            //            {
            //                mutex.ReleaseMutex();
            //            }
            //        }
            //        else
            //        {
            //            Console.WriteLine("mutex has not been released in 4 sec");
            //        }
            //    });
            //}
            //Console.ReadKey();


            //Mutex is used

            //  int ntasks = 0;
            //  int total_tasks = 5;
            //   Mutex m = new Mutex(false, "sample_mutex");
            //  Parallel.For(0, total_tasks, (i, state) => {
            // Thread.CurrentThread.Name = "thread-" + i;
            //while (true)
            // {
            //  try
            //  {
            //  if (m.WaitOne(100))
            // {
            //    Console.ForegroundColor = ConsoleColor.Green;
            //    Console.WriteLine("Working" + Thread.CurrentThread.Name);
            //    ntasks++;
            //    Thread.Sleep(1000);
            //     m.ReleaseMutex();
            //     break;
            //  }
            //  else
            // {
            //   Thread.Sleep(2000);
            //  Console.ForegroundColor = ConsoleColor.DarkRed;
            //  Console.WriteLine("slepping" + Thread.CurrentThread.Name);
            //    }
            // }
            // catch (Exception exc)
            //  {

            //   }

            //  }
            //});
            // if (ntasks != total_tasks)
            // {
            //  throw new Exception("weird some tasks haven't does the work" + ntasks);
            // }

            FileStream f = new FileStream("d:\\demo.txt", FileMode.OpenOrCreate);
            StreamReader s = new StreamReader(f);
            string line = "";
            while ((line = s.ReadLine()) != null)
            {
                Console.WriteLine(line);
                Thread.Sleep(2000);
            }
            s.Close();
            f.Close();
        }



    }
}














