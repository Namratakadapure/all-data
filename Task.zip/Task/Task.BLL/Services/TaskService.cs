﻿using AutoMapper;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Task.DAL.Repository;
using Task.IBLL.Interface;
using Task.Model;

namespace Task.BLL.Services
{
    public class TaskService : ITaskService

    {
        private readonly IMapper _mapper;

        private readonly TaskRepository taskRepository;
        public TaskService(TaskRepository taskRepository, IMapper mapper)
        {
            _mapper = mapper;
            this.taskRepository = taskRepository;
        }

        async Task<string> ExecuteGetRequest(string url)
        {
            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("Accept", "application/json");

            var apiresponse = await client.GetAsync(new Uri(url));
            if (apiresponse.IsSuccessStatusCode)
            {
                string result = await apiresponse.Content.ReadAsStringAsync();
                return result;
            }
            throw new Exception("Api Call Failed");
        }

        public async Task<List<ToDo>> InsertToDoData()
        {
            var url = "https://jsonplaceholder.typicode.com/todos";
            var res = await ExecuteGetRequest(url);
            var todos = JsonConvert.DeserializeObject<List<ToDo>>(res);
            var isSuccess = await taskRepository.InsertTodosIntoDb(todos);
            if (isSuccess is true)
            {
                return todos;
            }
            else
            {
                return null;
            }
        }

        public async Task<List<User>> InsertUserData()
        {
            var url = "https://jsonplaceholder.typicode.com/users";
            var res = await ExecuteGetRequest(url);
            var users = JsonConvert.DeserializeObject<List<User>>(res);
            var isSuccess = await taskRepository.InsertUsersIntoDb(users);
            if (isSuccess is true)
            {
                return users;
            }
            else
            {
                return null;
            }
        }

        public async Task<List<User>> GetUsers()
        {
            var result = await taskRepository.GetUsers();
            return result;

        }

    }
}