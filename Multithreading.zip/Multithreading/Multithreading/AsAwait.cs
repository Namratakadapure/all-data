﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Multithreading
{
    class AsAwait
    {
        public async void DoIt()
        {
            Task<int> t = Method1();
            
            Method2();
            await Method1();
            Console.WriteLine("Done Method1");
        }
        private async Task<int> Method1()
        {
            int counter = 0;
            await Task.Run(() =>
            {
                System.Threading.Thread.Sleep(3000);
                counter++;
            });
            return counter;
        }
        private void Method2()
        {
            Console.WriteLine("Done Method2");
        }
    }
}





