﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SF_Test.Model
{
     public class ExcelSheetModel
    {
        public int Slno { get; set; }
        public string StudName { get; set; }
        public string Dept { get; set; }
        public string Address { get; set; }
    }
}
